---
name: youtube-theory-korean
description: Extract English theory video transcripts, translate to Korean using ChatGPT, summarize, and send to Discord
triggers:
  - youtube theory
  - theory video
  - discord summary
  - korean theory
---

# YouTube Theory Korean Summarizer

This skill extracts transcripts from English theory videos, translates them to Korean using ChatGPT, creates a summary, and sends it to Discord.

## Activation

This skill activates when you:
- Provide a YouTube URL for a theory video (programming, CS, engineering, etc.)
- Ask to summarize an English theory video in Korean
- Request video content to be sent to Discord

## Process

When a YouTube URL is provided, the script will:

1. **Extract the Transcript**
   - Use youtube-transcript-api to fetch the video transcript
   - Download English captions/subtitles (manual or auto-generated)
   - Save transcript with timestamps

2. **Translate to Korean with ChatGPT**
   - Send transcript to OpenAI API (GPT-4 or GPT-3.5-turbo)
   - Request natural Korean translation
   - Maintain technical terminology accuracy

3. **Create Summary**
   - Generate concise Korean summary (300-500 words)
   - Highlight key concepts and main points
   - Structure for easy reading

4. **Send to Discord**
   - Post summary to configured Discord channel
   - Include video title and URL
   - Format with markdown for readability

## Usage Examples

**User:** "Summarize this theory video in Korean and send to Discord: https://www.youtube.com/watch?v=VIDEO_ID"

**User:** "Extract and translate this CS lecture: [YouTube URL]"

## Configuration

Requires `config.json` with:
```json
{
  "discord_channel_id": "YOUR_CHANNEL_ID",
  "discord_bot_token": "YOUR_BOT_TOKEN"
}
```

And environment variable:
```bash
export OPENAI_API_KEY="your_openai_api_key"
```

## Implementation Script

```python
#!/usr/bin/env python3
"""
YouTube Theory Korean Summarizer
Extracts English theory video transcripts, translates to Korean, and sends to Discord.
"""

import os
import sys
import json
import requests
from typing import Optional, Dict
from openai import OpenAI

# Configuration
CONFIG_FILE = "config.json"

def load_config() -> Dict:
    """Load configuration from config.json"""
    if not os.path.exists(CONFIG_FILE):
        print(f"Error: {CONFIG_FILE} not found!")
        print("Please create config.json from config.json.example")
        sys.exit(1)

    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def extract_video_id(url: str) -> Optional[str]:
    """Extract video ID from YouTube URL"""
    if 'youtu.be/' in url:
        return url.split('youtu.be/')[-1].split('?')[0]
    elif 'youtube.com/watch?v=' in url:
        return url.split('v=')[1].split('&')[0]
    return None

def get_transcript(video_id: str) -> Optional[str]:
    """Get transcript using youtube-transcript-api"""
    try:
        from youtube_transcript_api import YouTubeTranscriptApi

        # Try to get English transcript
        transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)

        try:
            transcript = transcript_list.find_transcript(['en'])
        except:
            # If no manual English, try auto-generated
            transcript = transcript_list.find_generated_transcript(['en'])

        transcript_data = transcript.fetch()

        # Combine all text
        full_text = ' '.join([entry['text'] for entry in transcript_data])
        return full_text

    except Exception as e:
        print(f"Error extracting transcript: {e}")
        return None

def get_video_title(video_id: str) -> str:
    """Get video title (simple approach without API)"""
    return f"YouTube Video (ID: {video_id})"

def translate_and_summarize(text: str, api_key: str) -> Dict[str, str]:
    """Translate to Korean and create summary using OpenAI"""
    client = OpenAI(api_key=api_key)

    # Create prompt for translation and summary
    prompt = f"""You are a technical translator and summarizer. Given the following English video transcript, please:

1. Provide a complete Korean translation (maintain technical accuracy)
2. Create a concise Korean summary (300-500 words) highlighting the main concepts

Transcript:
{text[:4000]}  # Limit to avoid token limits

Please format your response as:
## 한국어 번역
[translation here]

## 요약
[summary here]
"""

    try:
        response = client.chat.completions.create(
            model="gpt-4-turbo-preview",
            messages=[
                {"role": "system", "content": "You are a technical translator specializing in programming and computer science content."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=2000
        )

        result = response.choices[0].message.content

        # Parse the response
        parts = result.split("## 요약")
        translation = parts[0].replace("## 한국어 번역", "").strip()
        summary = parts[1].strip() if len(parts) > 1 else "요약을 생성할 수 없습니다."

        return {
            "translation": translation,
            "summary": summary
        }

    except Exception as e:
        print(f"Error in translation/summary: {e}")
        return {
            "translation": "번역 실패",
            "summary": "요약 실패"
        }

def send_to_discord(channel_id: str, bot_token: str, video_url: str, video_title: str, summary: str) -> bool:
    """Send summary to Discord channel"""
    url = f"https://discord.com/api/v10/channels/{channel_id}/messages"

    headers = {
        "Authorization": f"Bot {bot_token}",
        "Content-Type": "application/json"
    }

    # Format message with markdown
    message = f"""**📺 YouTube 이론 영상 요약**

**제목:** {video_title}
**링크:** {video_url}

**📋 요약:**
{summary}
"""

    payload = {
        "content": message
    }

    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        print("✅ Successfully sent to Discord!")
        return True

    except Exception as e:
        print(f"❌ Error sending to Discord: {e}")
        if hasattr(e, 'response'):
            print(f"Response: {e.response.text}")
        return False

def main():
    """Main execution function"""
    if len(sys.argv) < 2:
        print("Usage: python run.py <YouTube_URL>")
        sys.exit(1)

    video_url = sys.argv[1]

    # Load configuration
    print("📋 Loading configuration...")
    config = load_config()
    discord_channel_id = config.get('discord_channel_id')
    discord_bot_token = config.get('discord_bot_token')

    if not discord_channel_id or not discord_bot_token:
        print("Error: discord_channel_id or discord_bot_token not configured!")
        sys.exit(1)

    # Get OpenAI API key
    openai_api_key = os.getenv('OPENAI_API_KEY')
    if not openai_api_key:
        print("Error: OPENAI_API_KEY environment variable not set!")
        sys.exit(1)

    # Extract video ID
    print("🎬 Extracting video ID...")
    video_id = extract_video_id(video_url)
    if not video_id:
        print("Error: Invalid YouTube URL!")
        sys.exit(1)

    print(f"Video ID: {video_id}")

    # Get transcript
    print("📝 Extracting transcript...")
    transcript = get_transcript(video_id)
    if not transcript:
        print("Error: Could not extract transcript!")
        sys.exit(1)

    print(f"Transcript length: {len(transcript)} characters")

    # Get video title
    video_title = get_video_title(video_id)

    # Translate and summarize
    print("🤖 Translating and summarizing with ChatGPT...")
    result = translate_and_summarize(transcript, openai_api_key)

    print("\n" + "="*50)
    print("SUMMARY:")
    print("="*50)
    print(result['summary'])
    print("="*50 + "\n")

    # Send to Discord
    print("📤 Sending to Discord...")
    success = send_to_discord(
        discord_channel_id,
        discord_bot_token,
        video_url,
        video_title,
        result['summary']
    )

    if success:
        print("\n✅ All done!")
    else:
        print("\n❌ Failed to send to Discord")
        sys.exit(1)

if __name__ == "__main__":
    main()
```

## Requirements

- Python 3.7+
- openai library
- youtube-transcript-api library
- requests library
- Discord bot with channel access
- OpenAI API key

## Error Handling

If the process fails:
- **Transcript extraction fails**: Check if video has English captions
- **Translation fails**: Verify OpenAI API key and quota
- **Discord send fails**: Verify bot token and channel ID, ensure bot has Send Messages permission
- **Video not accessible**: May be region-restricted or private
