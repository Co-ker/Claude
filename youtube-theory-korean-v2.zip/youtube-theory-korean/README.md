# YouTube Theory Korean Summarizer

영어 이론 영상 → ChatGPT 번역 → 요약 → Discord 전송

## 📋 기능

- YouTube 영상에서 영어 자막 추출
- ChatGPT를 이용한 한국어 번역 및 요약
- Discord 채널로 자동 전송
- 프로그래밍/CS/공학 이론 영상에 최적화

## 🚀 설치 방법

### 1. 압축 해제

```bash
unzip youtube-theory-korean.zip
cd youtube-theory-korean
```

### 2. Python 패키지 설치

```bash
pip install -r requirements.txt
```

### 3. 설정 파일 생성

```bash
cp config.json.example config.json
```

그 다음 `config.json` 파일을 열어서 Discord 설정을 입력하세요:

```json
{
  "discord_channel_id": "1234567890123456789",
  "discord_bot_token": "YOUR_DISCORD_BOT_TOKEN_HERE"
}
```

### 4. OpenAI API Key 설정

```bash
export OPENAI_API_KEY="sk-your-openai-api-key-here"
```

또는 `.bashrc` / `.zshrc`에 추가:

```bash
echo 'export OPENAI_API_KEY="sk-your-openai-api-key-here"' >> ~/.bashrc
source ~/.bashrc
```

## 🎮 사용 방법

```bash
python run.py "https://www.youtube.com/watch?v=VIDEO_ID"
```

### 예시

```bash
python run.py "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
```

## 🤖 Discord Bot 설정

### 1. Discord Application 생성

1. https://discord.com/developers/applications 접속
2. "New Application" 클릭
3. 애플리케이션 이름 입력

### 2. Bot 생성

1. 왼쪽 메뉴에서 "Bot" 선택
2. "Add Bot" 클릭
3. "Reset Token" 클릭하여 토큰 복사
4. `config.json`의 `discord_bot_token`에 붙여넣기

### 3. Bot 권한 설정

1. "Bot" 페이지에서 다음 권한 활성화:
   - Send Messages
   - Embed Links
   - Read Message History

### 4. Bot을 서버에 초대

1. 왼쪽 메뉴에서 "OAuth2" → "URL Generator" 선택
2. Scopes에서 "bot" 체크
3. Bot Permissions에서 "Send Messages" 체크
4. 생성된 URL로 접속하여 서버에 Bot 초대

### 5. 채널 ID 가져오기

1. Discord 앱에서 "설정" → "고급" → "개발자 모드" 활성화
2. 원하는 채널에서 우클릭 → "채널 ID 복사"
3. `config.json`의 `discord_channel_id`에 붙여넣기

## 📝 출력 예시

스크립트를 실행하면 다음과 같은 과정이 진행됩니다:

```
📋 Loading configuration...
🎬 Extracting video ID...
Video ID: dQw4w9WgXcQ
📝 Extracting transcript...
Transcript length: 2847 characters
🤖 Translating and summarizing with ChatGPT...

==================================================
SUMMARY:
==================================================
[한국어 요약 내용]
==================================================

📤 Sending to Discord...
✅ Successfully sent to Discord!

✅ All done!
```

## 🔧 문제 해결

### Transcript extraction fails

- 영상에 영어 자막이 있는지 확인
- 자동 생성 자막이 활성화되어 있는지 확인
- 영상이 지역 제한이나 비공개가 아닌지 확인

### Translation fails

- OpenAI API 키가 올바른지 확인
- API 사용량 한도를 확인
- 인터넷 연결 확인

### Discord send fails

- Bot 토큰이 올바른지 확인
- 채널 ID가 올바른지 확인
- Bot이 해당 채널에 메시지 전송 권한이 있는지 확인
- Bot이 서버에 초대되어 있는지 확인

## 📦 파일 구조

```
youtube-theory-korean/
├── run.py                  # 메인 실행 스크립트
├── config.json.example     # 설정 파일 예시
├── requirements.txt        # Python 의존성
├── README.md              # 이 파일
├── SKILL.md               # 스킬 정의 문서
└── .gitignore             # Git 무시 파일
```

## 🔑 환경 변수

| 변수명 | 설명 | 필수 |
|--------|------|------|
| `OPENAI_API_KEY` | OpenAI API 키 | ✅ |

## ⚙️ 설정 파일 (config.json)

| 필드명 | 설명 | 예시 |
|--------|------|------|
| `discord_channel_id` | Discord 채널 ID | `"1234567890123456789"` |
| `discord_bot_token` | Discord Bot 토큰 | `"MTIzNDU2Nzg5MDEyMzQ1Njc4OQ..."` |

## 📄 라이선스

MIT License

## 🤝 기여

이슈나 Pull Request를 자유롭게 제출해주세요!

## 📧 문의

문제가 발생하면 GitHub Issues를 통해 문의해주세요.
